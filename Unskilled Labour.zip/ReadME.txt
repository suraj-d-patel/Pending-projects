The Project is a Dummy Website which composed of some functional links, which indirectly gives the idea of what the Project will be.
The Project is Composed of 4 html files. The Main moto of developement of Project is to provide a Social Platform to The Unskilled Labourers.The Labourer(User) is supposed to sign up to the form and Login to the Website using correct Credentials.
The user is supposed to choose the job which he can do
Jobs Menu is Displayed in Table fORMAT and upon clicking the job , user is directed to information about job and 
(un functional now)when job is cickced its Duration is diplayed and if the user is OK with the job to be done,
he is provided with the contact  and address...